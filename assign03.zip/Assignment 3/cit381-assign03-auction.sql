-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema assign03
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema assign03
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `assign03` DEFAULT CHARACTER SET utf8 ;
USE `assign03` ;

-- -----------------------------------------------------
-- Table `assign03`.`sellers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`sellers` ;

CREATE TABLE IF NOT EXISTS `assign03`.`sellers` (
  `sellerID` INT NOT NULL AUTO_INCREMENT,
  `sellerName` VARCHAR(45) NULL,
  PRIMARY KEY (`sellerID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign03`.`customers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`customers` ;

CREATE TABLE IF NOT EXISTS `assign03`.`customers` (
  `customerID` INT NOT NULL AUTO_INCREMENT,
  `customerName` VARCHAR(45) NULL,
  PRIMARY KEY (`customerID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign03`.`bids`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`bids` ;

CREATE TABLE IF NOT EXISTS `assign03`.`bids` (
  `bidID` INT NOT NULL AUTO_INCREMENT,
  `time_bid_placed` TIME NOT NULL,
  `bid_amount` FLOAT NOT NULL,
  `customers_customerID` INT NOT NULL,
  PRIMARY KEY (`bidID`, `customers_customerID`),
  INDEX `fk_bids_customers1_idx` (`customers_customerID` ASC) VISIBLE,
  CONSTRAINT `fk_bids_customers1`
    FOREIGN KEY (`customers_customerID`)
    REFERENCES `assign03`.`customers` (`customerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign03`.`items`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`items` ;

CREATE TABLE IF NOT EXISTS `assign03`.`items` (
  `itemID` INT NOT NULL AUTO_INCREMENT,
  `dispription` VARCHAR(255) NULL,
  `openingPrice` FLOAT NOT NULL,
  `reservePrice` FLOAT NOT NULL,
  `endTime` TIME NOT NULL,
  `sellers_sellerID` INT NOT NULL,
  `bids_bidID` INT NOT NULL,
  PRIMARY KEY (`itemID`, `sellers_sellerID`, `bids_bidID`),
  INDEX `fk_items_sellers_idx` (`sellers_sellerID` ASC) VISIBLE,
  INDEX `fk_items_bids1_idx` (`bids_bidID` ASC) VISIBLE,
  CONSTRAINT `fk_items_sellers`
    FOREIGN KEY (`sellers_sellerID`)
    REFERENCES `assign03`.`sellers` (`sellerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_items_bids1`
    FOREIGN KEY (`bids_bidID`)
    REFERENCES `assign03`.`bids` (`bidID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
