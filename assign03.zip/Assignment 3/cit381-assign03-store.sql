-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema assign03
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema assign03
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `assign03` DEFAULT CHARACTER SET utf8 ;
USE `assign03` ;

-- -----------------------------------------------------
-- Table `assign03`.`store`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`store` ;

CREATE TABLE IF NOT EXISTS `assign03`.`store` (
  `idStore` INT NOT NULL,
  `idEmployee` INT NOT NULL,
  PRIMARY KEY (`idStore`),
  INDEX `fk_store_employee1_idx` (`idEmployee` ASC) VISIBLE,
  CONSTRAINT `fk_store_employee1`
    FOREIGN KEY (`idEmployee`)
    REFERENCES `assign03`.`employee` (`idEmployee`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign03`.`employee`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`employee` ;

CREATE TABLE IF NOT EXISTS `assign03`.`employee` (
  `idEmployee` INT NOT NULL,
  `lastName` VARCHAR(45) NOT NULL,
  `firstName` VARCHAR(45) NULL,
  `managerID` INT NULL AUTO_INCREMENT,
  `hireDate` DATE NOT NULL,
  `releaseDate` DATE NULL,
  `idStore` INT NOT NULL,
  INDEX `fk_employee_store1_idx` (`idStore` ASC) VISIBLE,
  PRIMARY KEY (`idEmployee`),
  INDEX `fk_employee_employee1_idx` (`managerID` ASC) VISIBLE,
  CONSTRAINT `fk_employee_store1`
    FOREIGN KEY (`idStore`)
    REFERENCES `assign03`.`store` (`idStore`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_employee_employee1`
    FOREIGN KEY (`managerID`)
    REFERENCES `assign03`.`employee` (`idEmployee`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign03`.`region`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign03`.`region` ;

CREATE TABLE IF NOT EXISTS `assign03`.`region` (
  `idRegion` INT NOT NULL AUTO_INCREMENT,
  `idStore` INT NOT NULL,
  PRIMARY KEY (`idRegion`, `idStore`),
  INDEX `fk_region_store1_idx` (`idStore` ASC) VISIBLE,
  CONSTRAINT `fk_region_store1`
    FOREIGN KEY (`idStore`)
    REFERENCES `assign03`.`store` (`idStore`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
